Use tutorial given at https://sangams.com.np/installing-codeblocks-dark-themes/



location of original default.conf file C:\Users\USERNAME\AppData\Roaming\CodeBlocks\

If you can't find original default.conf run(double click) "Locate.bat" to open the location of your configuration file.

(USERNAME is your pc username)

https://samgams.com.np/