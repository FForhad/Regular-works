#include<bits/stdc++.h>
typedef long long int ll;
typedef long double ld;
using namespace std;

class Marks{
public:
    ll roll_number;
    string name;
    ll marks;
};
class Physics:public Marks{
public:

};
class Chemistry:public Marks{
public:

};
class Mathematics:public Marks{
public:

};
